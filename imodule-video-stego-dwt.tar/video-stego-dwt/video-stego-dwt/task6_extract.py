from pathlib import Path

import numpy as np
import pywt
from PIL import Image


SECRET_FILE = Path("secret.txt")
SELECTED_FILE = Path("selected_blocks.txt")
STEGO_FILE = Path("stego_frame.png")
EXTRACTED_FILE = Path("extracted.txt")
METRICS_FILE = Path("metrics.txt")
BLOCK_SIZE = 8


def read_selected_blocks():
    lines = SELECTED_FILE.read_text(encoding="utf-8").splitlines()[1:]
    blocks = []
    for line in lines:
        if not line.strip():
            continue
        row_text, col_text, _entropy = line.split(",")
        blocks.append((int(row_text), int(col_text)))
    return blocks


def extract_bit_from_block(block):
    coeffs = pywt.wavedec2(block, "haar", level=2)
    ll2 = coeffs[0]
    a = float(ll2[0, 1])
    b = float(ll2[1, 0])
    return "0" if abs(a) < abs(b) else "1"


def main():
    original = SECRET_FILE.read_text(encoding="utf-8").strip()
    selected_blocks = read_selected_blocks()[:len(original)]

    image = Image.open(STEGO_FILE).convert("YCbCr")
    y, _cb, _cr = image.split()
    y_arr = np.asarray(y, dtype=np.float64)

    bits = []
    for block_row, block_col in selected_blocks:
        row = block_row * BLOCK_SIZE
        col = block_col * BLOCK_SIZE
        block = y_arr[row:row + BLOCK_SIZE, col:col + BLOCK_SIZE]
        bits.append(extract_bit_from_block(block))

    extracted = "".join(bits)
    errors = sum(1 for a, b in zip(original, extracted) if a != b)
    ber = errors / len(original) if original else 0.0

    EXTRACTED_FILE.write_text(extracted + "\n", encoding="utf-8")
    METRICS_FILE.write_text(
        f"original={original}\n"
        f"extracted={extracted}\n"
        f"ber={ber:.1f}\n",
        encoding="utf-8",
    )

    print(f"original={original}")
    print(f"extracted={extracted}")
    print(f"ber={ber:.1f}")


if __name__ == "__main__":
    main()
