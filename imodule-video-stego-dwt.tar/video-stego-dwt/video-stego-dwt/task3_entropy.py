from pathlib import Path

import numpy as np
from PIL import Image


Y_IMAGE = Path("y_channel.png")
SECRET_FILE = Path("secret.txt")
SELECTED_FILE = Path("selected_blocks.txt")
ENTROPY_FILE = Path("entropy_map.txt")
BLOCK_SIZE = 8


def block_entropy(block):
    values, counts = np.unique(block, return_counts=True)
    probs = counts.astype(np.float64) / block.size
    return float(-np.sum(probs * np.log2(probs)))


def main():
    if not Y_IMAGE.exists():
        raise SystemExit("Missing y_channel.png. Run task2_y_channel.py first.")

    secret = SECRET_FILE.read_text(encoding="utf-8").strip()
    bit_count = len(secret)
    if bit_count == 0:
        raise SystemExit("secret.txt is empty.")

    image = Image.open(Y_IMAGE).convert("L")
    arr = np.asarray(image, dtype=np.uint8)
    height, width = arr.shape

    records = []
    for row in range(0, height - BLOCK_SIZE + 1, BLOCK_SIZE):
        for col in range(0, width - BLOCK_SIZE + 1, BLOCK_SIZE):
            block = arr[row:row + BLOCK_SIZE, col:col + BLOCK_SIZE]
            entropy = block_entropy(block)
            records.append((row // BLOCK_SIZE, col // BLOCK_SIZE, entropy))

    if len(records) < bit_count:
        raise SystemExit("Not enough 8x8 blocks for all secret bits.")

    records.sort(key=lambda item: item[2])
    selected = records[:bit_count]

    with SELECTED_FILE.open("w", encoding="utf-8") as f:
        f.write("row,col,entropy\n")
        for row, col, entropy in selected:
            f.write(f"{row},{col},{entropy:.6f}\n")

    with ENTROPY_FILE.open("w", encoding="utf-8") as f:
        f.write("row,col,entropy\n")
        for row, col, entropy in records:
            f.write(f"{row},{col},{entropy:.6f}\n")

    print(f"selected_blocks={len(selected)}")
    print(f"total_blocks={len(records)}")


if __name__ == "__main__":
    main()
