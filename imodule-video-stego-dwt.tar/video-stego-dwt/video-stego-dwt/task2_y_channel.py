from pathlib import Path

from PIL import Image


FRAME_DIR = Path("frames")
SCENE_FILE = Path("scene_frames.txt")
Y_IMAGE = Path("y_channel.png")
DONE_FILE = Path("y_done.txt")


def main():
    if not SCENE_FILE.exists():
        raise SystemExit("Missing scene_frames.txt. Run task1_scene.py first.")

    scene_name = SCENE_FILE.read_text(encoding="utf-8").splitlines()[0].strip()
    image_path = FRAME_DIR / scene_name
    if not image_path.exists():
        raise SystemExit(f"Missing selected frame: {image_path}")

    image = Image.open(image_path).convert("RGB")
    ycbcr = image.convert("YCbCr")
    y, cb, cr = ycbcr.split()

    y.save(Y_IMAGE)
    DONE_FILE.write_text("y_channel_created\n", encoding="utf-8")

    print(f"created={Y_IMAGE}")
    print(f"source={image_path}")


if __name__ == "__main__":
    main()
