from pathlib import Path

import numpy as np
from PIL import Image


FRAME_DIR = Path("frames")
OUT_FILE = Path("scene_frames.txt")


def grayscale_histogram(image_path):
    image = Image.open(image_path).convert("L")
    arr = np.asarray(image, dtype=np.uint8)
    hist, _ = np.histogram(arr, bins=256, range=(0, 256))
    return hist.astype(np.float64)


def main():
    frames = sorted(FRAME_DIR.glob("frame_*.png"))
    if len(frames) < 2:
        raise SystemExit("Need at least two frames in frames/")

    histograms = [grayscale_histogram(frame) for frame in frames]
    diffs = []

    for i in range(len(histograms) - 1):
        diff = np.sum(np.abs(histograms[i] - histograms[i + 1]))
        diffs.append(diff)

    diffs = np.asarray(diffs, dtype=np.float64)
    threshold = float(np.mean(diffs) + 2 * np.std(diffs))

    selected = []
    for i, diff in enumerate(diffs):
        if diff > threshold:
            selected.append(frames[i + 1].name)

    # Neu khong co frame nao vuot nguong, chon frame co sai khac lon nhat
    # de bai lab luon co mot frame dau vao cho cac task tiep theo.
    if not selected:
        selected.append(frames[int(np.argmax(diffs)) + 1].name)

    with OUT_FILE.open("w", encoding="utf-8") as f:
        for name in selected:
            f.write(name + "\n")

    print(f"threshold={threshold:.3f}")
    print("selected=" + ",".join(selected))


if __name__ == "__main__":
    main()
