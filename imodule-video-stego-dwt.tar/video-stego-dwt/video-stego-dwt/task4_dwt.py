from pathlib import Path

import numpy as np
import pywt
from PIL import Image


Y_IMAGE = Path("y_channel.png")
SELECTED_FILE = Path("selected_blocks.txt")
OUT_FILE = Path("dwt_coeffs.txt")
BLOCK_SIZE = 8


def read_first_block_position():
    lines = SELECTED_FILE.read_text(encoding="utf-8").splitlines()
    if len(lines) < 2:
        raise SystemExit("selected_blocks.txt has no selected block.")
    row_text, col_text, _entropy = lines[1].split(",")
    return int(row_text), int(col_text)


def main():
    if not Y_IMAGE.exists():
        raise SystemExit("Missing y_channel.png.")
    if not SELECTED_FILE.exists():
        raise SystemExit("Missing selected_blocks.txt. Run task3_entropy.py first.")

    block_row, block_col = read_first_block_position()
    arr = np.asarray(Image.open(Y_IMAGE).convert("L"), dtype=np.float64)
    row = block_row * BLOCK_SIZE
    col = block_col * BLOCK_SIZE
    block = arr[row:row + BLOCK_SIZE, col:col + BLOCK_SIZE]

    coeffs = pywt.wavedec2(block, "haar", level=2)
    ll2 = coeffs[0]
    a = float(ll2[0, 1])
    b = float(ll2[1, 0])

    OUT_FILE.write_text(f"a={a:.6f}\nb={b:.6f}\n", encoding="utf-8")
    print(f"a={a:.6f}")
    print(f"b={b:.6f}")


if __name__ == "__main__":
    main()
