# Lab: Video Steganography with Scene Change, Entropy and DWT

## Mục tiêu

Hoàn thành 6 task:

1. Phát hiện scene-change bằng histogram.
2. Tách kênh Y trong không gian màu YCbCr.
3. Chia block 8x8 và tính entropy.
4. Thực hiện DWT 2 mức.
5. Nhúng bit bằng quan hệ hai hệ số DWT.
6. Trích xuất message và tính BER.

## Task 1

Viết `task1_scene.py`.

Đọc các ảnh trong `frames/`, tính histogram grayscale, tính sai khác histogram giữa hai frame liên tiếp.

```text
D_hist(i) = sum(|Hist(F_i) - Hist(F_{i+1})|)
threshold = mean(D_hist) + 2 * std(D_hist)
```

Nếu `D_hist(i) > threshold`, chọn `F_{i+1}` là frame chuyển cảnh.

Đầu ra:

```text
scene_frames.txt
```

## Task 2

Viết `task2_y_channel.py`.

Đọc frame trong `scene_frames.txt`, chuyển RGB sang YCbCr, tách kênh Y.

Đầu ra:

```text
y_channel.png
y_done.txt
```

`y_done.txt` chứa:

```text
y_channel_created
```

## Task 3

Viết `task3_entropy.py`.

Đọc `y_channel.png`, chia block 8x8, tính entropy:

```text
H = - sum(p(i) * log2(p(i)))
```

Đầu ra:

```text
selected_blocks.txt
entropy_map.txt
```

## Task 4

Viết `task4_dwt.py`.

Lấy block đầu tiên trong `selected_blocks.txt`, DWT 2 mức, ghi:

```text
a = LL2(0,1)
b = LL2(1,0)
```

Đầu ra:

```text
dwt_coeffs.txt
```

## Task 5

Viết `task5_embed.py`.

Nhúng mỗi bit trong `secret.txt` vào một block bằng quan hệ:

```text
|a| < |b|  -> bit 0
|a| >= |b| -> bit 1
```

Với:

```text
T = 13
```

Đầu ra:

```text
stego_frame.png
embed_log.txt
```

## Task 6

Viết `task6_extract.py`.

Đọc `stego_frame.png`, trích xuất bit, so sánh với `secret.txt`, tính BER.

Đầu ra:

```text
extracted.txt
metrics.txt
```

`metrics.txt` cần có:

```text
ber=0.0
```

## Lệnh chạy

```bash
python3 task1_scene.py
python3 task2_y_channel.py
python3 task3_entropy.py
python3 task4_dwt.py
python3 task5_embed.py
python3 task6_extract.py
```
