from pathlib import Path

import numpy as np
import pywt
from PIL import Image


FRAME_DIR = Path("frames")
SCENE_FILE = Path("scene_frames.txt")
SECRET_FILE = Path("secret.txt")
SELECTED_FILE = Path("selected_blocks.txt")
STEGO_FILE = Path("stego_frame.png")
LOG_FILE = Path("embed_log.txt")
BLOCK_SIZE = 8
T = 13.0


def increase_magnitude(value, amount):
    return value + amount if value >= 0 else value - amount


def read_selected_blocks():
    lines = SELECTED_FILE.read_text(encoding="utf-8").splitlines()[1:]
    blocks = []
    for line in lines:
        if not line.strip():
            continue
        row_text, col_text, _entropy = line.split(",")
        blocks.append((int(row_text), int(col_text)))
    return blocks


def embed_bit_in_block(block, bit):
    coeffs = pywt.wavedec2(block, "haar", level=2)
    ll2 = coeffs[0].copy()
    a = float(ll2[0, 1])
    b = float(ll2[1, 0])
    relation = "ok"

    if bit == "1":
        if abs(a) < abs(b):
            a, b = b, a
            relation = "swapped"
        a = increase_magnitude(a, T)
    else:
        if abs(a) >= abs(b):
            a, b = b, a
            relation = "swapped"
        b = increase_magnitude(b, T)

    ll2[0, 1] = a
    ll2[1, 0] = b
    new_coeffs = [ll2, coeffs[1], coeffs[2]]
    stego_block = pywt.waverec2(new_coeffs, "haar")
    return np.clip(np.rint(stego_block), 0, 255), relation


def main():
    secret = SECRET_FILE.read_text(encoding="utf-8").strip()
    if not set(secret).issubset({"0", "1"}):
        raise SystemExit("secret.txt must contain only bits 0 and 1.")

    scene_name = SCENE_FILE.read_text(encoding="utf-8").splitlines()[0].strip()
    image = Image.open(FRAME_DIR / scene_name).convert("RGB")
    ycbcr = image.convert("YCbCr")
    y, cb, cr = ycbcr.split()
    y_arr = np.asarray(y, dtype=np.float64).copy()

    selected_blocks = read_selected_blocks()
    if len(selected_blocks) < len(secret):
        raise SystemExit("Not enough selected blocks for secret bits.")

    logs = []
    for bit, (block_row, block_col) in zip(secret, selected_blocks):
        row = block_row * BLOCK_SIZE
        col = block_col * BLOCK_SIZE
        block = y_arr[row:row + BLOCK_SIZE, col:col + BLOCK_SIZE]
        stego_block, relation = embed_bit_in_block(block, bit)
        y_arr[row:row + BLOCK_SIZE, col:col + BLOCK_SIZE] = stego_block
        logs.append(f"bit={bit} row={block_row} col={block_col} relation={relation}")

    stego_y = Image.fromarray(np.uint8(np.clip(y_arr, 0, 255)), mode="L")
    stego_ycbcr = Image.merge("YCbCr", (stego_y, cb, cr))
    stego_rgb = stego_ycbcr.convert("RGB")
    stego_rgb.save(STEGO_FILE)
    LOG_FILE.write_text("\n".join(logs) + "\n", encoding="utf-8")

    print(f"created={STEGO_FILE}")
    print(f"embedded_bits={len(secret)}")


if __name__ == "__main__":
    main()
